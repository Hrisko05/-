<!DOCTYPE html>
<html>
<head>
    <title>Библиотека</title>
    <style>
        body { font-family: sans-serif; padding: 50px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
        .btn { background: #28a745; color: white; padding: 8px; text-decoration: none; border-radius: 4px; border: none; cursor: pointer; }
        .msg { padding: 10px; margin-bottom: 20px; border: 1px solid transparent; }
        .success { color: #155724; background: #d4edda; }
        .error { color: #721c24; background: #f8d7da; }
    </style>
</head>
<body>
    <div style="text-align: right; padding: 10px; background: #eee; margin-bottom: 20px;">
    <?php if(auth()->guard()->check()): ?>
        <span>Здравей, <strong><?php echo e(Auth::user()->name); ?></strong></span> | 
        <form action="<?php echo e(route('logout')); ?>" method="POST" style="display:inline;">
            <?php echo csrf_field(); ?>
            <button type="submit" style="background:none; border:none; color:red; cursor:pointer;">Изход</button>
        </form>
    <?php else: ?>
        <a href="<?php echo e(route('login')); ?>">Вход</a> | 
        <a href="<?php echo e(route('register')); ?>">Регистрация</a>
    <?php endif; ?>
</div>
    <h1>Библиотечна Система</h1>
   
    
<?php if(Auth::check() && Auth::user()->role == 'admin'): ?>
<a href="<?php echo e(route('users.create')); ?>" style="float: right; background: #6c757d; color: white; padding: 10px; text-decoration: none; border-radius: 5px;">+ Нов Админ</a>
    <div style="background: #f4f4f4; padding: 20px; border-radius: 8px; margin-bottom: 30px;">
        <?php endif; ?>
        <?php if(Auth::check() && Auth::user()->role == 'admin'): ?>
    <div class="add-book-section"></div>
        <h3>Добави нова книга</h3>
       <form action="<?php echo e(route('books.store')); ?>" method="POST" enctype="multipart/form-data">
           <?php echo csrf_field(); ?> <input type="text" name="title" placeholder="Заглавие" required style="padding: 8px; width: 200px;">
            <input type="text" name="author" placeholder="Автор" required style="padding: 8px; width: 200px;">
            <input type="number" name="quantity" placeholder="Бройки" required style="padding: 8px; width: 80px;">
            <input type="file" name="cover_image" style="padding: 8px; width: 250px;">
            <button type="submit" class="btn" style="background: #007bff; padding: 10px 20px;">Добави книгата</button>
        </form>
    </div>
    <?php endif; ?>

    <?php if(session('success')): ?> <div class="msg success"><?php echo e(session('success')); ?></div> <?php endif; ?>
    <?php if(session('error')): ?> <div class="msg error"><?php echo e(session('error')); ?></div> <?php endif; ?>

    <table>
  <thead>
    <tr>
        <th>Заглавие</th>
        <th>Автор</th>
        <th>Наличност</th>
        <th>Действие</th> <th>Корица</th>
    </tr>
</thead>
<tbody>
    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($book->title); ?></td>
        <td><?php echo e($book->author); ?></td>
        <td><?php echo e($book->quantity); ?> бр.</td>
        <td>
            <?php if(auth()->guard()->check()): ?>
                <?php if($book->quantity > 0): ?>
                    <form action="<?php echo e(route('books.borrow', $book->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn" style="background: #28a745; color: white;">Вземи</button>
                    </form>
                <?php else: ?>
                    <span style="color: red;">Изчерпана</span>
                <?php endif; ?>

                <?php if(Auth::user()->role == 'admin'): ?>
                    <a href="<?php echo e(route('books.edit', $book->id)); ?>" class="btn" style="background: #ffc107; color: black; text-decoration: none; display: inline-block; padding: 2px 10px; border-radius: 4px; margin-left: 5px;">Редактирай</a>
                    
                    <form action="<?php echo e(route('books.destroy', $book->id)); ?>" method="POST" style="display:inline; margin-left: 5px;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn" style="background: #dc3545; color: white;" onclick="return confirm('Сигурни ли сте?')">Изтрий</button>
                    </form>
                <?php endif; ?>
            <?php endif; ?>
        </td>
        <td>
            <?php if($book->cover_image): ?>
                <img src="<?php echo e(asset($book->cover_image)); ?>" width="50">
            <?php else: ?>
                Няма корица
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody> </table> 
    
    <hr>
    
    <h2>Заети в момента</h2>
    <table>
    <thead>
    <tr>
        <th>Книга</th>
        <th>Взета на</th>
        <th>Взета от</th>
        <?php if(Auth::user()->role !== 'admin'): ?>
            <th>Действие</th>
        <?php endif; ?>
    </tr>
</thead>
<tbody>
    <?php $__currentLoopData = $borrowedBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $borrow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($borrow->book->title); ?></td>
            <td><?php echo e($borrow->created_at); ?></td>

            <td>
                <span style="font-weight: bold; color: #555;">
                    <?php echo e($borrow->user->name); ?> </span>
            </td>

            <?php if(Auth::user()->role !== 'admin'): ?>
                <td>
                    <form action="<?php echo e(route('books.return', $borrow->book_id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn" style="background: #007bff; color: white;">Върни</button>
                    </form>
                </td>
            <?php endif; ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
    </table>

</body> </html><?php /**PATH C:\Users\hrist_man4kty\library-system\resources\views/welcome.blade.php ENDPATH**/ ?>