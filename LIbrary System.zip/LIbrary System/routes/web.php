<?php
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BookController;
use App\Models\Book;
use Illuminate\Support\Facades\Auth;
Route::post('/return/{id}', [BookController::class, 'returnBook'])->name('books.return');
Route::get('/', [BookController::class, 'index'])->middleware('auth');
Route::post('/borrow/{id}', [BookController::class, 'borrow'])->name('books.borrow'); 
Route::post('/books/store', [BookController::class, 'store'])->name('books.store');
Route::delete('/books/{id}', [BookController::class, 'destroy'])->name('books.destroy');
Route::get('/books/{id}/edit', [BookController::class, 'edit'])->name('books.edit');
Route::put('/books/{id}', [BookController::class, 'update'])->name('books.update');
Route::get('/admin/users/create', [UserController::class, 'create'])->name('users.create');
Route::post('/admin/users/store', [UserController::class, 'store'])->name('users.store');


Route::get('/add-test-book', function () {
    Book::create([
        'title' => 'Под игото',
        'author' => 'Иван Вазов',
        'quantity' => 5
    ]);
    return "Книгата е добавена успешно!";
});
Route::get('/library', function () {
    $books = \App\Models\Book::all(); 
    return view('welcome', ['books' => $books]); 
});
Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
