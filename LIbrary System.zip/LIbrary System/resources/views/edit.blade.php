<!DOCTYPE html>
<html>
<head>
    <title>Редактиране на книга</title>
    <style>
        body { font-family: sans-serif; padding: 50px; }
        input { display: block; margin-bottom: 10px; padding: 8px; width: 300px; }
        .btn { background: #ffc107; color: black; padding: 10px; border: none; cursor: pointer; }
    </style>
</head>
<body>
    <h1>Редактиране на: {{ $book->title }}</h1>
    <form action="{{ route('books.update', $book->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT') <label>Заглавие:</label>
        <input type="text" name="title" value="{{ $book->title }}" required>
        
        <label>Автор:</label>
        <input type="text" name="author" value="{{ $book->author }}" required>
        
        <label>Количество:</label>
        <input type="number" name="quantity" value="{{ $book->quantity }}" required>
        
        <label>Нова корица (по избор):</label>
        <input type="file" name="cover_image">

        <button type="submit" class="btn">Запази промените</button>
        <a href="/">Отказ</a>
    </form>
</body>
</html>