<!DOCTYPE html>
<html>
<head>
    <title>Добави Администратор</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { font-family: sans-serif; padding: 50px; background: #f4f4f4; }
        /* Подобрение: Малко сянка за по-модерен вид */
        .card { background: white; padding: 30px; border-radius: 8px; width: 400px; margin: auto; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
        input { display: block; width: 100%; margin-bottom: 15px; padding: 10px; box-sizing: border-box; border: 1px solid #ddd; border-radius: 4px; }
        .btn { background: #007bff; color: white; border: none; padding: 10px 20px; cursor: pointer; width: 100%; border-radius: 4px; }
        .btn:hover { background: #0056b3; }
    </style>
</head>
<body>
    <div class="card">
        <h2>Нов Администратор</h2>

        @if ($errors->any())
            <div style="color: red; margin-bottom: 15px;">
                @foreach ($errors->all() as $error)
                    <small>• {{ $error }}</small><br>
                @endforeach
            </div>
        @endif

        <form action="{{ route('users.store') }}" method="POST">
            @csrf
            <input type="text" name="name" placeholder="Име" value="{{ old('name') }}" required>
            <input type="email" name="email" placeholder="Имейл" value="{{ old('email') }}" required>
            <input type="password" name="password" placeholder="Парола" required>
            <button type="submit" class="btn">Създай потребител</button>
        </form>
        <br>
        <a href="/" style="text-decoration: none; color: #666;">← Назад към библиотеката</a>
    </div>
</body>
</html>