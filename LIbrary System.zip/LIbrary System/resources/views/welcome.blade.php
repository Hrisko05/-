<!DOCTYPE html>
<html>
<head>
    <title>Библиотека</title>
    <style>
        body { font-family: sans-serif; padding: 50px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
        .btn { background: #28a745; color: white; padding: 8px; text-decoration: none; border-radius: 4px; border: none; cursor: pointer; }
        .msg { padding: 10px; margin-bottom: 20px; border: 1px solid transparent; }
        .success { color: #155724; background: #d4edda; }
        .error { color: #721c24; background: #f8d7da; }
    </style>
</head>
<body>
    <div style="text-align: right; padding: 10px; background: #eee; margin-bottom: 20px;">
    @auth
        <span>Здравей, <strong>{{ Auth::user()->name }}</strong></span> | 
        <form action="{{ route('logout') }}" method="POST" style="display:inline;">
            @csrf
            <button type="submit" style="background:none; border:none; color:red; cursor:pointer;">Изход</button>
        </form>
    @else
        <a href="{{ route('login') }}">Вход</a> | 
        <a href="{{ route('register') }}">Регистрация</a>
    @endauth
</div>
    <h1>Библиотечна Система</h1>
   
    
@if(Auth::check() && Auth::user()->role == 'admin')
<a href="{{ route('users.create') }}" style="float: right; background: #6c757d; color: white; padding: 10px; text-decoration: none; border-radius: 5px;">+ Нов Админ</a>
    <div style="background: #f4f4f4; padding: 20px; border-radius: 8px; margin-bottom: 30px;">
        @endif
        @if(Auth::check() && Auth::user()->role == 'admin')
    <div class="add-book-section"></div>
        <h3>Добави нова книга</h3>
       <form action="{{ route('books.store') }}" method="POST" enctype="multipart/form-data">
           @csrf <input type="text" name="title" placeholder="Заглавие" required style="padding: 8px; width: 200px;">
            <input type="text" name="author" placeholder="Автор" required style="padding: 8px; width: 200px;">
            <input type="number" name="quantity" placeholder="Бройки" required style="padding: 8px; width: 80px;">
            <input type="file" name="cover_image" style="padding: 8px; width: 250px;">
            <button type="submit" class="btn" style="background: #007bff; padding: 10px 20px;">Добави книгата</button>
        </form>
    </div>
    @endif

    @if(session('success')) <div class="msg success">{{ session('success') }}</div> @endif
    @if(session('error')) <div class="msg error">{{ session('error') }}</div> @endif

    <table>
  <thead>
    <tr>
        <th>Заглавие</th>
        <th>Автор</th>
        <th>Наличност</th>
        <th>Действие</th> <th>Корица</th>
    </tr>
</thead>
<tbody>
    @foreach($books as $book)
    <tr>
        <td>{{ $book->title }}</td>
        <td>{{ $book->author }}</td>
        <td>{{ $book->quantity }} бр.</td>
        <td>
            @auth
                @if($book->quantity > 0)
                    <form action="{{ route('books.borrow', $book->id) }}" method="POST" style="display:inline;">
                        @csrf
                        <button type="submit" class="btn" style="background: #28a745; color: white;">Вземи</button>
                    </form>
                @else
                    <span style="color: red;">Изчерпана</span>
                @endif

                @if(Auth::user()->role == 'admin')
                    <a href="{{ route('books.edit', $book->id) }}" class="btn" style="background: #ffc107; color: black; text-decoration: none; display: inline-block; padding: 2px 10px; border-radius: 4px; margin-left: 5px;">Редактирай</a>
                    
                    <form action="{{ route('books.destroy', $book->id) }}" method="POST" style="display:inline; margin-left: 5px;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn" style="background: #dc3545; color: white;" onclick="return confirm('Сигурни ли сте?')">Изтрий</button>
                    </form>
                @endif
            @endauth
        </td>
        <td>
            @if($book->cover_image)
                <img src="{{ asset($book->cover_image) }}" width="50">
            @else
                Няма корица
            @endif
        </td>
    </tr>
    @endforeach
</tbody> </table> 
    
    <hr>
    
    <h2>Заети в момента</h2>
    <table>
    <thead>
    <tr>
        <th>Книга</th>
        <th>Взета на</th>
        <th>Взета от</th>
        @if(Auth::user()->role !== 'admin')
            <th>Действие</th>
        @endif
    </tr>
</thead>
<tbody>
    @foreach($borrowedBooks as $borrow)
        <tr>
            <td>{{ $borrow->book->title }}</td>
            <td>{{ $borrow->created_at }}</td>

            <td>
                <span style="font-weight: bold; color: #555;">
                    {{ $borrow->user->name }} </span>
            </td>

            @if(Auth::user()->role !== 'admin')
                <td>
                    <form action="{{ route('books.return', $borrow->book_id) }}" method="POST">
                        @csrf
                        <button type="submit" class="btn" style="background: #007bff; color: white;">Върни</button>
                    </form>
                </td>
            @endif
        </tr>
    @endforeach
</tbody>
    </table>

</body> </html>