<?php

namespace App\Http\Controllers;

use App\Models\Book;
use App\Models\Borrowing;
use Illuminate\Http\Request;

class BookController extends Controller
{
  
   public function index() {
    $books = Book::all();
    $borrowedBooks = Borrowing::whereNull('returned_at')->with('book')->get();
    return view('welcome', compact('books', 'borrowedBooks'));
}

   
  public function borrow($id)
{
    $book = Book::findOrFail($id);

    if ($book->quantity > 0) {
        $book->quantity -= 1;
        $book->save();

      
        Borrowing::create([
            'book_id' => $book->id,
            'user_id' => auth()->id(), 
        ]);

        return back()->with('success', 'Успешно заехте книгата: ' . $book->title);
    }

    return back()->with('error', 'Съжаляваме, в момента няма налични бройки от тази книга.');
}

   
    public function returnBook($id)
    {
        
        $borrowing = Borrowing::where('book_id', $id)
                               ->whereNull('returned_at')
                               ->first();

        if ($borrowing) {
            
            $borrowing->update([
                'returned_at' => now()
            ]);

            
            $book = Book::find($id);
            $book->quantity += 1;
            $book->save();

            return back()->with('success', 'Успешно върнахте книгата: ' . $book->title);
        }

        return back()->with('error', 'Грешка: Тази книга не е намерена в списъка на заетите.');
    }

    
public function store(Request $request) {
    $request->validate([
        'title' => 'required',
        'author' => 'required',
        'quantity' => 'required|numeric|min:1',
        'cover_image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048', 
    ]);

    $imagePath = null;
    if ($request->hasFile('cover_image')) {
        $imageName = time().'.'.$request->cover_image->extension();
        $request->cover_image->move(public_path('images/covers'), $imageName);
        $imagePath = 'images/covers/' . $imageName;
    }

    Book::create([
        'title' => $request->title,
        'author' => $request->author,
        'quantity' => $request->quantity,
        'cover_image' => $imagePath, 
    ]);

    return back()->with('success', 'Новата книга е добавена в библиотеката!');
}
public function destroy($id) {
    $book = Book::findOrFail($id);
    $book->delete(); 

    return back()->with('success', 'Книгата беше изтрита успешно!');
}

public function edit($id) {
    $book = Book::findOrFail($id);
    return view('edit', compact('book'));
}


public function update(Request $request, $id) {
    $book = Book::findOrFail($id);
    
    $data = $request->validate([
        'title' => 'required',
        'author' => 'required',
        'quantity' => 'required|numeric',
    ]);

    if ($request->hasFile('cover_image')) {
        $imageName = time().'.'.$request->cover_image->extension();
        $request->cover_image->move(public_path('images/covers'), $imageName);
        $data['cover_image'] = 'images/covers/' . $imageName;
    }

    $book->update($data);
    return redirect('/')->with('success', 'Книгата е редактирана успешно!');
}

}